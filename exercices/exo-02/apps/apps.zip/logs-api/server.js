const express = require("express");
const fs = require("fs");
const bodyParser = require("body-parser");

const app = express();
const PORT = process.env.PORT || 3000;
const DATA_FILE = "logs.json";

app.use(bodyParser.json());

// Initialiser le fichier de données si inexistant ou si c’est un dossier
if (!fs.existsSync(DATA_FILE) || fs.lstatSync(DATA_FILE).isDirectory()) {
  fs.writeFileSync(DATA_FILE, JSON.stringify([]));
}

// 🔹 GET /api/v1/logs
app.get("/api/v1/logs", (req, res) => {
  try {
    const data = fs.readFileSync(DATA_FILE, "utf-8");
    const logs = JSON.parse(data);
    res.status(200).json(logs);
  } catch (err) {
    res.status(500).json({ error: "Erreur lors de la lecture des logs" });
  }
});

// 🔹 POST /api/v1/logs
app.post("/api/v1/logs", (req, res) => {
  const { timestamp, method, endpoint, message, ip } = req.body;

  if (!timestamp || !method || !endpoint || !message || !ip) {
    return res.status(400).json({ error: "Champs manquants dans le corps de la requête" });
  }

  const newLog = { timestamp, method, endpoint, message, ip };

  try {
    const data = fs.readFileSync(DATA_FILE, "utf-8");
    const logs = JSON.parse(data);
    logs.push(newLog);
    fs.writeFileSync(DATA_FILE, JSON.stringify(logs, null, 2));
    res.status(201).json({ message: "Log ajouté avec succès", log: newLog });
  } catch (err) {
    res.status(500).json({ error: "Erreur lors de l'enregistrement du log" });
  }
});

app.listen(PORT, () => {
  console.log(`🚀 Serveur en écoute sur http://localhost:${PORT}`);
});
