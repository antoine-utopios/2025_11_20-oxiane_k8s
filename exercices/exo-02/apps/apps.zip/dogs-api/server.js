const express = require("express");
const bodyParser = require("body-parser");
const axios = require("axios");
const { v4: uuidv4 } = require("uuid");
const fs = require("fs");
require("dotenv").config();

const app = express();
const PORT = process.env.PORT || 4000;
const LOGS_API_URL = process.env.LOGS_API_URL;
const DATA_FILE = "dogs.json";

app.use(bodyParser.json());

// Initialiser le fichier de données si inexistant ou si c’est un dossier
if (!fs.existsSync(DATA_FILE) || fs.lstatSync(DATA_FILE).isDirectory()) {
  fs.writeFileSync(DATA_FILE, JSON.stringify([]));
}

// ---- Fonction pour envoyer un log à l'API Logs ----
async function sendLog(method, endpoint, message, ip = "unknown") {
  if (!LOGS_API_URL) {
    console.warn("⚠️  LOGS_API_URL non défini, le log ne sera pas envoyé");
    return;
  }

  try {
    await axios.post(LOGS_API_URL, {
      timestamp: new Date().toISOString(),
      method,
      endpoint,
      message,
      ip,
    });
  } catch (err) {
    console.error("❌ Erreur lors de l'envoi du log :", err.message);
  }
}

// ---- CRUD ----

// 🔹 GET /api/v1/dogs
app.get("/api/v1/dogs", async (req, res) => {
  const dogs = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  await sendLog("GET", "/api/v1/dogs", "Liste des chiens récupérée", req.ip);
  res.json(dogs);
});

// 🔹 GET /api/v1/dogs/:dogId
app.get("/api/v1/dogs/:dogId", async (req, res) => {
  const dogs = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  const dog = dogs.find(d => d.id === req.params.dogId);
  if (!dog) {
    await sendLog("GET", `/api/v1/dogs/${req.params.dogId}`, "Chien non trouvé", req.ip);
    return res.status(404).json({ error: "Chien non trouvé" });
  }
  await sendLog("GET", `/api/v1/dogs/${req.params.dogId}`, "Chien récupéré", req.ip);
  res.json(dog);
});

// 🔹 POST /api/v1/dogs
app.post("/api/v1/dogs", async (req, res) => {
  const { name, breed, birthDate } = req.body;
  if (!name || !breed || !birthDate) {
    return res.status(400).json({ error: "Champs manquants" });
  }

  const dogs = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  const newDog = { id: uuidv4(), name, breed, birthDate };
  dogs.push(newDog);
  fs.writeFileSync(DATA_FILE, JSON.stringify(dogs, null, 2));

  await sendLog("POST", "/api/v1/dogs", `Nouveau chien ajouté (${name})`, req.ip);
  res.status(201).json(newDog);
});

// 🔹 PATCH /api/v1/dogs/:dogId
app.patch("/api/v1/dogs/:dogId", async (req, res) => {
  const { name, breed, birthDate } = req.body;
  const dogs = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  const dogIndex = dogs.findIndex(d => d.id === req.params.dogId);

  if (dogIndex === -1) {
    await sendLog("PATCH", `/api/v1/dogs/${req.params.dogId}`, "Chien non trouvé", req.ip);
    return res.status(404).json({ error: "Chien non trouvé" });
  }

  if (name) dogs[dogIndex].name = name;
  if (breed) dogs[dogIndex].breed = breed;
  if (birthDate) dogs[dogIndex].birthDate = birthDate;

  fs.writeFileSync(DATA_FILE, JSON.stringify(dogs, null, 2));

  await sendLog("PATCH", `/api/v1/dogs/${req.params.dogId}`, "Chien mis à jour", req.ip);
  res.json(dogs[dogIndex]);
});

// 🔹 DELETE /api/v1/dogs/:dogId
app.delete("/api/v1/dogs/:dogId", async (req, res) => {
  const dogs = JSON.parse(fs.readFileSync(DATA_FILE, "utf-8"));
  const newDogs = dogs.filter(d => d.id !== req.params.dogId);

  if (dogs.length === newDogs.length) {
    await sendLog("DELETE", `/api/v1/dogs/${req.params.dogId}`, "Chien non trouvé", req.ip);
    return res.status(404).json({ error: "Chien non trouvé" });
  }

  fs.writeFileSync(DATA_FILE, JSON.stringify(newDogs, null, 2));
  await sendLog("DELETE", `/api/v1/dogs/${req.params.dogId}`, "Chien supprimé", req.ip);
  res.json({ message: "Chien supprimé" });
});

app.listen(PORT, () => {
  console.log(`🐶 Dogs API en écoute sur http://localhost:${PORT}`);
});
